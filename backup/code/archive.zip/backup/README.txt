Please do not modify or delete this folder.
It will contain your latest backup when you decide to do one.

Howto back up your work:

* Go into your Visual Studio Code termina
* Run the command /home/coder/project/backup/script/backup.sh
* Copy the address from your web browser's address bar when you are viewing Visual Studio
* Append /download/ to the end of the address (don't miss out the / at the end)
* You will be taken to the backup download page

For more information on how to backup/download your work, plaese follow the lab instructions.


