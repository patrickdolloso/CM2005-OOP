# Video 1.105 Writing our first program
## Converting C++ into a program

```
g++ -S main.cpp --> produces assembler

g++ -c main.cpp --> produces object code

g++ main.cpp --> compile assemble and link
```

