#include <iostream>

int main()
{
    std::cout << "Hello" << std::endl;

    int x;
    std::cin >> x;
    
    std::cout << "You typed: " << x << std::endl;

    return 0;
}