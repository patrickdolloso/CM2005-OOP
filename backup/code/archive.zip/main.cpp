# include <iostream>

int main()
{
    while (true)
    {
        // 1 print help
        std::cout << "1: print help" << std::endl;

        // 2 print exchange stats
        std::cout << "2: print exchange stats" << std::endl;

        // 3 make an offer
        std::cout << "3: make an offer" << std::endl;

        // 4 make a bid
        std::cout << "4: make a bid" << std::endl;

        // 5 print wallet
        std::cout << "5: print wallet" << std::endl;

        // 6 continue
        std::cout << "6: continue" << std::endl;

        std::cout << "======" << std::endl;
        std::cout << "Type 1-6" << std::endl;    


        int user0ption;
        std::cin >> user0ption;
        std::cout << "You chose: " << user0ption << std::endl;

        if (user0ption == 0) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 1) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 2) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 3) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 4) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 5) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

        if (user0ption == 6) //bad input
        {
            std::cout << "invalid choice. Choose 1-6" << std::endl;
        }

    }

    return 0;
}