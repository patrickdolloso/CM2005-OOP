# include <iostream>

int main()
{
    std::cout << "let's trade !" << std::endl;
}